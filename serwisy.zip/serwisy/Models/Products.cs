﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace serwisy.Models
{
    public class Products
    {
        [Required]
        public int Id { get; set; }
        [Required, MaxLength(1000)]
        public string Maker { get; set; }

        [JsonPropertyName("img"),Required]
        public string Image { get; set; }
        [Required, MaxLength(1000)]
        public string Url { get; set; }
        [Required, MaxLength(1000)]
        public string Title { get; set; }
        [Required, MaxLength(1000)]
        public string Description { get; set; }


        public override string ToString() => JsonSerializer.Serialize<Products>(this);
       
    }
}
