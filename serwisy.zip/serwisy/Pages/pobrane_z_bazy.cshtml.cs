using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using serwisy.Data;
using serwisy.Models;

namespace serwisy.Pages
{
    public class pobrane_z_bazyModel : PageModel
    {
        private readonly ProductsContext _context;
        public IList<Products> Productlist { get; set; }
        public pobrane_z_bazyModel(ProductsContext context)
        {
            _context = context;
        }
        public void OnGet()
        {
            Productlist = _context.Product.ToList();
        }
    }
}
